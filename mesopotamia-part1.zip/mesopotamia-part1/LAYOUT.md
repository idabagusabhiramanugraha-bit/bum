# Tabel koordinat (piksel, kanvas 1080x1920)

## Global (koordinat kanvas)
| Elemen | x | y | lebar | tinggi |
|---|---|---|---|---|
| title | 60 | 90 | 960 | 140 |
| stage | 0 | 260 | 1080 | 1140 |
| subtitle | 60 | 1460 | 960 | 260 |

## Per beat (koordinat lokal stage; origin stage = x0,y260 di kanvas)

### b1
| Elemen | x | y | lebar | tinggi |
|---|---|---|---|---|
| stickman | 60 | 720 | 240 | 400 |
| chipMesopotamia | 330 | 760 | 420 | 100 |
| labelTurki | 142 | 134 | 160 | 60 |
| labelSuriah | 164 | 340 | 160 | 60 |
| labelIrak | 392 | 477 | 160 | 60 |
| labelIran | 733 | 386 | 160 | 60 |

### b2
| Elemen | x | y | lebar | tinggi |
|---|---|---|---|---|
| placard | 40 | 30 | 540 | 130 |
| year | 40 | 176 | 300 | 64 |
| king | 730 | 30 | 310 | 390 |
| stickman | 730 | 560 | 310 | 540 |
| pin1 | 40 | 720 | 200 | 140 |
| pin2 | 260 | 720 | 200 | 140 |
| pin3 | 480 | 720 | 200 | 140 |

### b3
| Elemen | x | y | lebar | tinggi |
|---|---|---|---|---|
| placard | 40 | 30 | 540 | 130 |
| year | 40 | 176 | 300 | 64 |
| king | 730 | 30 | 310 | 390 |
| stickman | 730 | 560 | 310 | 540 |

### b4
| Elemen | x | y | lebar | tinggi |
|---|---|---|---|---|
| placard | 40 | 30 | 540 | 130 |
| year | 40 | 176 | 300 | 64 |
| king | 730 | 30 | 310 | 390 |
| stickman | 730 | 560 | 310 | 540 |
| pin1 | 40 | 720 | 200 | 140 |

### b5
| Elemen | x | y | lebar | tinggi |
|---|---|---|---|---|
| placard | 40 | 30 | 540 | 130 |
| year | 40 | 176 | 300 | 64 |
| king | 730 | 30 | 310 | 390 |
| stickman | 730 | 560 | 310 | 540 |
| pin1 | 40 | 720 | 200 | 140 |
| pin2 | 260 | 720 | 200 | 140 |

### b6
| Elemen | x | y | lebar | tinggi |
|---|---|---|---|---|
| chip1 | 40 | 40 | 480 | 84 |
| chip2 | 560 | 40 | 480 | 84 |
| chip3 | 40 | 140 | 480 | 84 |
| chip4 | 560 | 140 | 480 | 84 |
| stickman | 730 | 560 | 310 | 540 |

### b7
| Elemen | x | y | lebar | tinggi |
|---|---|---|---|---|
| wordmark | 40 | 440 | 700 | 130 |
| king | 730 | 30 | 310 | 390 |
| stickman | 60 | 600 | 300 | 520 |

Lapisan latar (langit, potongan latar, tanah, peta) sengaja berada di belakang dan tidak dihitung.
Transisi: Wipe menutup penuh stage tepat saat beat berganti (frame tengah), sehingga elemen beat lama dan baru tidak pernah tampil bersamaan.
Title diganti saat wipe menutup stage; title dan subtitle berada di luar stage sehingga tidak tertimpa wipe.
