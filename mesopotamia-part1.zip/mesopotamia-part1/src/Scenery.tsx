import React from 'react';
import {Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {C} from './theme';
import L from './layout.json';

const GROUND_Y = L.bg.bandBottom; // 760
const W = 1080;

/** Langit datar dua pita + awan yang melayang (gerak dari frame, tanpa acak). */
export const Sky: React.FC<{sky: string; horizon: string}> = ({sky, horizon}) => {
  const f = useCurrentFrame();
  const cloud = (base: number, y: number, sp: number, k: number) => {
    const x = ((base + f * sp) % 1500) - 250;
    return (
      <g key={k} transform={`translate(${x} ${y})`} fill="#FFFFFF" opacity={0.9}>
        <ellipse cx={0} cy={0} rx={110} ry={30} />
        <ellipse cx={-60} cy={-18} rx={60} ry={26} />
        <ellipse cx={50} cy={-24} rx={70} ry={30} />
      </g>
    );
  };
  return (
    <svg width={W} height={GROUND_Y} style={{position: 'absolute', left: 0, top: 0}}>
      <rect x={0} y={0} width={W} height={GROUND_Y} fill={sky} />
      <rect x={0} y={GROUND_Y - 300} width={W} height={300} fill={horizon} />
      {cloud(100, 300, 0.35, 1)}
      {cloud(700, 200, 0.22, 2)}
      {cloud(1200, 380, 0.3, 3)}
    </svg>
  );
};

/** Potongan latar dari gambar, dengan parallax pelan dan zoom opsional. */
export const Band: React.FC<{
  src: string;
  h: number;
  dur: number;
  zoomTo?: number;
  origin?: string;
  children?: React.ReactNode;
}> = ({src, h, dur, zoomTo = 1.12, origin = 'center center', children}) => {
  const f = useCurrentFrame();
  const s = interpolate(f, [0, dur], [1.08, zoomTo], {extrapolateRight: 'clamp'});
  const tx = interpolate(f, [0, dur], [-18, 18], {extrapolateRight: 'clamp'});
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        top: GROUND_Y - h,
        width: W,
        height: h,
        overflow: 'hidden',
        WebkitMaskImage: 'linear-gradient(to bottom, transparent 0px, black 36px)',
        maskImage: 'linear-gradient(to bottom, transparent 0px, black 36px)',
      }}
    >
      <Img
        src={staticFile(src)}
        style={{width: W, height: h, transformOrigin: origin, transform: `translateX(${tx}px) scale(${s})`}}
      />
      {children}
    </div>
  );
};

/** Tanah depan dengan garis perspektif menuju titik hilang. */
export const Ground: React.FC<{children?: React.ReactNode}> = ({children}) => {
  const H = 1140 - GROUND_Y;
  const vx = 540;
  const bottoms = [-500, -150, 200, 540, 880, 1230, 1580];
  const hs = [30, 70, 125, 205, 300, 375];
  return (
    <svg width={W} height={H} style={{position: 'absolute', left: 0, top: GROUND_Y}}>
      <rect x={0} y={0} width={W} height={H} fill={C.sand} />
      {bottoms.map((b) => (
        <line key={b} x1={vx} y1={0} x2={b} y2={H} stroke={C.sandDark} strokeWidth={4} />
      ))}
      {hs.map((y) => (
        <line key={y} x1={0} y1={y} x2={W} y2={y} stroke={C.sandDark} strokeWidth={4} />
      ))}
      <rect x={0} y={0} width={W} height={8} fill={C.ink} />
      {children}
    </svg>
  );
};
