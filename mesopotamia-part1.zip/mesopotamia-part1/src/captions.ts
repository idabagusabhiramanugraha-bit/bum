// FILE HASIL GENERATE dari data/narasi.srt (npm run captions). Jangan edit manual.
export type Word = {w: string; start: number; end: number; cue: number};
export const WORDS: Word[] = [
 {
  "w": "Peradaban",
  "start": 0.08,
  "end": 0.751,
  "cue": 0
 },
 {
  "w": "Mesopotamia",
  "start": 0.751,
  "end": 1.571,
  "cue": 0
 },
 {
  "w": "berada",
  "start": 1.571,
  "end": 2.019,
  "cue": 0
 },
 {
  "w": "di",
  "start": 2.019,
  "end": 2.168,
  "cue": 0
 },
 {
  "w": "kawasan",
  "start": 2.168,
  "end": 2.69,
  "cue": 0
 },
 {
  "w": "yang",
  "start": 2.69,
  "end": 2.988,
  "cue": 0
 },
 {
  "w": "sekarang",
  "start": 2.988,
  "end": 3.585,
  "cue": 0
 },
 {
  "w": "dikenal",
  "start": 3.585,
  "end": 4.107,
  "cue": 0
 },
 {
  "w": "sebagai",
  "start": 4.107,
  "end": 4.629,
  "cue": 0
 },
 {
  "w": "Irak,",
  "start": 4.629,
  "end": 4.927,
  "cue": 0
 },
 {
  "w": "serta",
  "start": 4.927,
  "end": 5.3,
  "cue": 0
 },
 {
  "w": "sebagian",
  "start": 5.3,
  "end": 6.112,
  "cue": 1
 },
 {
  "w": "Suriah,",
  "start": 6.112,
  "end": 6.722,
  "cue": 1
 },
 {
  "w": "Turki,",
  "start": 6.722,
  "end": 7.229,
  "cue": 1
 },
 {
  "w": "dan",
  "start": 7.229,
  "end": 7.534,
  "cue": 1
 },
 {
  "w": "Iran.",
  "start": 7.534,
  "end": 7.94,
  "cue": 1
 },
 {
  "w": "Di",
  "start": 8.64,
  "end": 8.808,
  "cue": 2
 },
 {
  "w": "bagian",
  "start": 8.808,
  "end": 9.313,
  "cue": 2
 },
 {
  "w": "selatan,",
  "start": 9.313,
  "end": 9.903,
  "cue": 2
 },
 {
  "w": "terdapat",
  "start": 9.903,
  "end": 10.576,
  "cue": 2
 },
 {
  "w": "Sumeria",
  "start": 10.576,
  "end": 11.165,
  "cue": 2
 },
 {
  "w": "dengan",
  "start": 11.165,
  "end": 11.67,
  "cue": 2
 },
 {
  "w": "kota-kota",
  "start": 11.67,
  "end": 12.344,
  "cue": 2
 },
 {
  "w": "penting",
  "start": 12.344,
  "end": 12.933,
  "cue": 2
 },
 {
  "w": "seperti",
  "start": 12.933,
  "end": 13.522,
  "cue": 2
 },
 {
  "w": "Uruk,",
  "start": 13.522,
  "end": 13.859,
  "cue": 2
 },
 {
  "w": "Ur,",
  "start": 13.859,
  "end": 14.027,
  "cue": 2
 },
 {
  "w": "dan",
  "start": 14.027,
  "end": 14.28,
  "cue": 2
 },
 {
  "w": "Lagash.",
  "start": 14.28,
  "end": 14.769,
  "cue": 3
 },
 {
  "w": "Di",
  "start": 14.769,
  "end": 14.933,
  "cue": 3
 },
 {
  "w": "bagian",
  "start": 14.933,
  "end": 15.422,
  "cue": 3
 },
 {
  "w": "tengah,",
  "start": 15.422,
  "end": 15.911,
  "cue": 3
 },
 {
  "w": "terdapat",
  "start": 15.911,
  "end": 16.564,
  "cue": 3
 },
 {
  "w": "wilayah",
  "start": 16.564,
  "end": 17.135,
  "cue": 3
 },
 {
  "w": "Akkadia",
  "start": 17.135,
  "end": 17.706,
  "cue": 3
 },
 {
  "w": "yang",
  "start": 17.706,
  "end": 18.032,
  "cue": 3
 },
 {
  "w": "pernah",
  "start": 18.032,
  "end": 18.521,
  "cue": 3
 },
 {
  "w": "menjadi",
  "start": 18.521,
  "end": 19.092,
  "cue": 3
 },
 {
  "w": "pusat",
  "start": 19.092,
  "end": 19.5,
  "cue": 3
 },
 {
  "w": "kekaisaran",
  "start": 19.5,
  "end": 20.297,
  "cue": 4
 },
 {
  "w": "besar",
  "start": 20.297,
  "end": 20.696,
  "cue": 4
 },
 {
  "w": "di",
  "start": 20.696,
  "end": 20.855,
  "cue": 4
 },
 {
  "w": "bawah",
  "start": 20.855,
  "end": 21.254,
  "cue": 4
 },
 {
  "w": "Sargon.",
  "start": 21.254,
  "end": 21.732,
  "cue": 4
 },
 {
  "w": "Tak",
  "start": 21.732,
  "end": 21.971,
  "cue": 4
 },
 {
  "w": "jauh",
  "start": 21.971,
  "end": 22.29,
  "cue": 4
 },
 {
  "w": "dari",
  "start": 22.29,
  "end": 22.609,
  "cue": 4
 },
 {
  "w": "sana,",
  "start": 22.609,
  "end": 22.928,
  "cue": 4
 },
 {
  "w": "terdapat",
  "start": 22.928,
  "end": 23.565,
  "cue": 4
 },
 {
  "w": "Babilonia",
  "start": 23.565,
  "end": 24.283,
  "cue": 4
 },
 {
  "w": "dengan",
  "start": 24.283,
  "end": 24.761,
  "cue": 4
 },
 {
  "w": "kota",
  "start": 24.761,
  "end": 25.08,
  "cue": 4
 },
 {
  "w": "terkenalnya,",
  "start": 25.08,
  "end": 26.106,
  "cue": 5
 },
 {
  "w": "yaitu",
  "start": 26.106,
  "end": 26.572,
  "cue": 5
 },
 {
  "w": "Babilon.",
  "start": 26.572,
  "end": 27.224,
  "cue": 5
 },
 {
  "w": "Sementara",
  "start": 27.224,
  "end": 28.063,
  "cue": 5
 },
 {
  "w": "di",
  "start": 28.063,
  "end": 28.25,
  "cue": 5
 },
 {
  "w": "bagian",
  "start": 28.25,
  "end": 28.809,
  "cue": 5
 },
 {
  "w": "utara,",
  "start": 28.809,
  "end": 29.275,
  "cue": 5
 },
 {
  "w": "terdapat",
  "start": 29.275,
  "end": 30.021,
  "cue": 5
 },
 {
  "w": "wilayah",
  "start": 30.021,
  "end": 30.674,
  "cue": 5
 },
 {
  "w": "Asyur",
  "start": 30.674,
  "end": 31.14,
  "cue": 5
 },
 {
  "w": "dengan",
  "start": 31.14,
  "end": 31.574,
  "cue": 6
 },
 {
  "w": "kota-kota",
  "start": 31.574,
  "end": 32.153,
  "cue": 6
 },
 {
  "w": "penting",
  "start": 32.153,
  "end": 32.66,
  "cue": 6
 },
 {
  "w": "seperti",
  "start": 32.66,
  "end": 33.167,
  "cue": 6
 },
 {
  "w": "Asyur",
  "start": 33.167,
  "end": 33.529,
  "cue": 6
 },
 {
  "w": "dan",
  "start": 33.529,
  "end": 33.746,
  "cue": 6
 },
 {
  "w": "Niniwe.",
  "start": 33.746,
  "end": 34.18,
  "cue": 6
 },
 {
  "w": "Selain",
  "start": 34.92,
  "end": 35.326,
  "cue": 7
 },
 {
  "w": "kerajaan-kerajaan",
  "start": 35.326,
  "end": 36.409,
  "cue": 7
 },
 {
  "w": "tersebut,",
  "start": 36.409,
  "end": 36.951,
  "cue": 7
 },
 {
  "w": "Mesopotamia",
  "start": 36.951,
  "end": 37.695,
  "cue": 7
 },
 {
  "w": "juga",
  "start": 37.695,
  "end": 37.966,
  "cue": 7
 },
 {
  "w": "memiliki",
  "start": 37.966,
  "end": 38.508,
  "cue": 7
 },
 {
  "w": "dataran",
  "start": 38.508,
  "end": 38.982,
  "cue": 7
 },
 {
  "w": "subur,",
  "start": 38.982,
  "end": 39.32,
  "cue": 7
 },
 {
  "w": "lahan",
  "start": 39.68,
  "end": 40.067,
  "cue": 8
 },
 {
  "w": "pertanian,",
  "start": 40.067,
  "end": 40.764,
  "cue": 8
 },
 {
  "w": "jalur",
  "start": 40.764,
  "end": 41.151,
  "cue": 8
 },
 {
  "w": "perdagangan,",
  "start": 41.151,
  "end": 42.003,
  "cue": 8
 },
 {
  "w": "dan",
  "start": 42.003,
  "end": 42.236,
  "cue": 8
 },
 {
  "w": "permukiman",
  "start": 42.236,
  "end": 43.01,
  "cue": 8
 },
 {
  "w": "kuno.",
  "start": 43.01,
  "end": 43.32,
  "cue": 8
 },
 {
  "w": "Inilah",
  "start": 44,
  "end": 44.424,
  "cue": 9
 },
 {
  "w": "Mesopotamia,",
  "start": 44.424,
  "end": 45.202,
  "cue": 9
 },
 {
  "w": "wilayah",
  "start": 45.202,
  "end": 45.697,
  "cue": 9
 },
 {
  "w": "yang",
  "start": 45.697,
  "end": 45.98,
  "cue": 9
 },
 {
  "w": "menjadi",
  "start": 45.98,
  "end": 46.475,
  "cue": 9
 },
 {
  "w": "tempat",
  "start": 46.475,
  "end": 46.899,
  "cue": 9
 },
 {
  "w": "berkembangnya",
  "start": 46.899,
  "end": 47.818,
  "cue": 9
 },
 {
  "w": "berbagai",
  "start": 47.818,
  "end": 48.384,
  "cue": 9
 },
 {
  "w": "peradaban",
  "start": 48.384,
  "end": 49.02,
  "cue": 9
 },
 {
  "w": "besar",
  "start": 49.02,
  "end": 49.429,
  "cue": 10
 },
 {
  "w": "di",
  "start": 49.429,
  "end": 49.593,
  "cue": 10
 },
 {
  "w": "antara",
  "start": 49.593,
  "end": 50.084,
  "cue": 10
 },
 {
  "w": "dua",
  "start": 50.084,
  "end": 50.329,
  "cue": 10
 },
 {
  "w": "sungai.",
  "start": 50.329,
  "end": 50.82,
  "cue": 10
 }
];
