import React from 'react';
import {interpolate, Sequence, useCurrentFrame} from 'remotion';
import {C} from './theme';
import L from './layout.json';

const D = 14; // durasi wipe (frame); menutup penuh di tengah
const WW = 1900;

const Inner: React.FC = () => {
  const f = useCurrentFrame();
  const tx = interpolate(f, [0, D - 1], [-1400, 1400]);
  const H = L.global.stage[3];
  return (
    <div style={{position: 'absolute', left: L.global.stage[0], top: L.global.stage[1], width: L.global.stage[2], height: H, overflow: 'hidden'}}>
      <svg width={WW} height={H} style={{position: 'absolute', left: -410 + tx, top: 0}}>
        <polygon points={`160,0 ${WW},0 ${WW - 160},${H} 0,${H}`} fill={C.ink} />
        <polygon points={`${WW - 70},0 ${WW},0 ${WW - 160},${H} ${WW - 230},${H}`} fill={C.gold} />
      </svg>
    </div>
  );
};

/** Wipe lempeng tanah: menutup stage penuh tepat pada frame `at` (saat beat berganti). */
export const Wipe: React.FC<{at: number}> = ({at}) => (
  <Sequence from={at - Math.floor(D / 2)} durationInFrames={D}>
    <Inner />
  </Sequence>
);
