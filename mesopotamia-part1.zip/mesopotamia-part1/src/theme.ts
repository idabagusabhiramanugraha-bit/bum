export const C = {
  night: '#1B120C',
  ink: '#2A1B10',
  parchment: '#E8D3A2',
  parchmentDark: '#C9AE74',
  gold: '#D4A63A',
  lapis: '#1F3F8F',
  terracotta: '#B4482A',
  cape: '#8E2218',
  sand: '#D9B070',
  sandDark: '#B98A4E',
  yellow: '#FFD21F',
  cream: '#FFF3D6',
};
export const SERIF = "Georgia, 'Times New Roman', serif";
export const SANS = "'Segoe UI', Arial, Helvetica, sans-serif";
