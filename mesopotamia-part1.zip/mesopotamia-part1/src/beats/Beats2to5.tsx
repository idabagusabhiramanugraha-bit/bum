import React from 'react';
import {Kingdom, KCfg} from './Kingdom';
import {findPhrase, findWord} from '../timing';

type P = {start: number; dur: number};

const idxSelatan = findPhrase(['di', 'bagian', 'selatan']);
const idxUruk = findWord('uruk', idxSelatan);
const idxUr = findWord('ur', idxSelatan);
const idxLagash = findWord('lagash', idxSelatan);
const idxKekaisaran = findWord('kekaisaran');
const idxBabilon = findWord('babilon', findPhrase(['tak', 'jauh', 'dari']));
const idxUtara = findPhrase(['sementara', 'di', 'bagian']);
const idxAssur = findPhrase(['seperti', 'asyur'], idxUtara) + 1;
const idxNiniwe = findWord('niniwe', idxUtara);

const B2: KCfg = {
  id: 'b2',
  title: 'Selatan: Tanah Sumeria',
  placard: 'SUMERIA',
  year: '±3500 SM',
  king: {img: 'img/king_gilgamesh.png', name: 'Gilgamesh', role: 'Raja Uruk'},
  band: {src: 'img/band4.png', h: 250},
  sky: '#8EC3E6',
  horizon: '#CFE3EE',
  pins: [
    {label: 'Uruk', word: idxUruk},
    {label: 'Ur', word: idxUr},
    {label: 'Lagash', word: idxLagash},
  ],
};
const B3: KCfg = {
  id: 'b3',
  title: 'Tengah: Kekaisaran Akkadia',
  placard: 'AKKADIA',
  year: '±2334 SM',
  king: {img: 'img/king_sargon.png', name: 'Sargon', role: 'Pendiri Akkadia'},
  band: {src: 'img/band5.png', h: 295},
  sky: '#A9CFE8',
  horizon: '#F0DDB0',
  pins: [],
  arrowWord: idxKekaisaran,
};
const B4: KCfg = {
  id: 'b4',
  title: 'Gerbang Babilonia',
  placard: 'BABILONIA',
  year: '±1792 SM',
  king: {img: 'img/king_hammurabi.png', name: 'Hammurabi', role: 'Raja Babilonia'},
  band: {src: 'img/band6.png', h: 295, zoomTo: 1.45, origin: '47% 55%'},
  sky: '#7FB0DB',
  horizon: '#C7DDEE',
  pins: [{label: 'Babilon', word: idxBabilon}],
};
const B5: KCfg = {
  id: 'b5',
  title: 'Utara: Benteng Asyur',
  placard: 'ASYUR',
  year: '±705 SM',
  king: {img: 'img/king_sennacherib.png', name: 'Sennacherib', role: 'Raja Asyur'},
  band: {src: 'img/band7.png', h: 281},
  sky: '#B8CFDC',
  horizon: '#E6D3B0',
  pins: [
    {label: 'Assur', word: idxAssur},
    {label: 'Niniwe', word: idxNiniwe},
  ],
};

export const Beat2: React.FC<P> = (p) => <Kingdom cfg={B2} {...p} />;
export const Beat3: React.FC<P> = (p) => <Kingdom cfg={B3} {...p} />;
export const Beat4: React.FC<P> = (p) => <Kingdom cfg={B4} {...p} />;
export const Beat5: React.FC<P> = (p) => <Kingdom cfg={B5} {...p} />;
