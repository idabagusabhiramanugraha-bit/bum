import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Band, Ground, Sky} from '../Scenery';
import {Stickman} from '../Stickman';
import {KingCard, Pin, Placard, SceneTitle, Stage, YearChip, usePop} from '../ui';
import {localFrame} from '../timing';
import {C} from '../theme';
import L from '../layout.json';

export type KCfg = {
  id: 'b2' | 'b3' | 'b4' | 'b5';
  title: string;
  placard: string;
  year: string;
  king: {img: string; name: string; role: string};
  band: {src: string; h: number; zoomTo?: number; origin?: string};
  sky: string;
  horizon: string;
  pins: {label: string; word: number}[];
  arrowWord?: number;
};

/** Panah wilayah yang melebar (dipakai Akkadia: pusat kekaisaran meluas). Di dalam Band. */
const RegionArrow: React.FC<{delay: number; h: number}> = ({delay, h}) => {
  const f = useCurrentFrame();
  const t = interpolate(f - delay, [0, 26], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  if (f < delay) return null;
  const cy = h / 2;
  return (
    <svg width={1080} height={h} style={{position: 'absolute', left: 0, top: 0}}>
      <g transform={`translate(60 0) scale(${t} 1) translate(-60 0)`}>
        <polygon
          points={`60,${cy - 28} 720,${cy - 28} 720,${cy - 70} 1010,${cy} 720,${cy + 70} 720,${cy + 28} 60,${cy + 28}`}
          fill={C.terracotta}
          fillOpacity={0.6}
          stroke={C.ink}
          strokeWidth={5}
        />
      </g>
    </svg>
  );
};

export const Kingdom: React.FC<{cfg: KCfg; start: number; dur: number}> = ({cfg, start, dur}) => {
  const f = useCurrentFrame();
  const B = (L.beats as Record<string, Record<string, number[]>>)[cfg.id];
  const point = usePop(14, 12);
  const armL = f < 14 ? 8 : 8 + (92 + Math.sin(f / 9) * 8 - 8) * point;
  return (
    <AbsoluteFill>
      <SceneTitle text={cfg.title} />
      <Stage>
        <Sky sky={cfg.sky} horizon={cfg.horizon} />
        <Band src={cfg.band.src} h={cfg.band.h} dur={dur} zoomTo={cfg.band.zoomTo} origin={cfg.band.origin}>
          {cfg.arrowWord !== undefined ? <RegionArrow delay={localFrame(cfg.arrowWord, start)} h={cfg.band.h} /> : null}
        </Band>
        <Ground />
        <Placard rect={B.placard} text={cfg.placard} delay={6} />
        <YearChip rect={B.year} text={cfg.year} delay={14} />
        <KingCard rect={B.king} img={cfg.king.img} name={cfg.king.name} role={cfg.king.role} delay={10} />
        {cfg.pins.map((p, i) => (
          <Pin key={p.label} rect={B['pin' + (i + 1)]} label={p.label} delay={localFrame(p.word, start)} />
        ))}
        <Stickman rect={B.stickman} armL={armL} armR={8} />
      </Stage>
    </AbsoluteFill>
  );
};
