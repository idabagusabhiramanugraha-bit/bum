import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Band, Ground, Sky} from '../Scenery';
import {Stickman} from '../Stickman';
import {SceneTitle, Stage, Tablet, usePop} from '../ui';
import {findWord, localFrame} from '../timing';
import {C, SERIF} from '../theme';
import L from '../layout.json';

type P = {start: number; dur: number};

const iSelain = findWord('selain');
const WORD_IDX = [findWord('dataran', iSelain), findWord('lahan', iSelain), findWord('jalur', iSelain), findWord('permukiman', iSelain)];
const LABELS = ['Dataran subur', 'Lahan tani', 'Jalur dagang', 'Permukiman'];

const Chip: React.FC<{rect: number[]; text: string; delay: number}> = ({rect, text, delay}) => {
  const f = useCurrentFrame();
  const s = usePop(delay, 12);
  if (f < delay) return null;
  return (
    <div style={{position: 'absolute', left: rect[0], top: rect[1], width: rect[2], height: rect[3], transform: `translateY(${(1 - s) * -160}px)`}}>
      <Tablet w={rect[2]} h={rect[3]} fill={C.lapis} stroke={C.gold} sw={5} cut={12}>
        <div style={{fontFamily: SERIF, fontWeight: 900, fontSize: 44, color: C.parchment}}>{text}</div>
      </Tablet>
    </div>
  );
};

/** Ladang tumbuh dari kiri ke kanan di tanah depan (garis perspektif). */
const Fields: React.FC<{delay: number}> = ({delay}) => {
  const f = useCurrentFrame();
  const w = interpolate(f - delay, [0, 48], [0, 1080], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const H = 1140 - L.bg.bandBottom;
  const bottoms = [-500, -150, 200, 540, 880, 1230, 1580];
  return (
    <g clipPath="url(#fieldclip)">
      <clipPath id="fieldclip">
        <rect x={0} y={0} width={w} height={H} />
      </clipPath>
      {bottoms.slice(0, -1).map((b, i) => (
        <polygon key={b} points={`540,8 ${b},${H} ${bottoms[i + 1]},${H}`} fill={i % 2 === 0 ? '#C9A93B' : '#6E8F3A'} />
      ))}
    </g>
  );
};

export const Beat6: React.FC<P> = ({start, dur}) => {
  const f = useCurrentFrame();
  const B = L.beats.b6;
  const rects = [B.chip1, B.chip2, B.chip3, B.chip4];
  const point = usePop(10, 12);
  const armL = f < 10 ? 8 : 8 + (96 + Math.sin(f / 9) * 8 - 8) * point;
  return (
    <AbsoluteFill>
      <SceneTitle text="Tanah yang Subur" />
      <Stage>
        <Sky sky="#9CCBEA" horizon="#D5E8F0" />
        <Band src="img/band8.png" h={446} dur={dur} zoomTo={1.1} />
        <Ground>
          <Fields delay={localFrame(WORD_IDX[1], start)} />
        </Ground>
        {rects.map((r, i) => (
          <Chip key={i} rect={r} text={LABELS[i]} delay={localFrame(WORD_IDX[i], start)} />
        ))}
        <Stickman rect={B.stickman} armL={armL} armR={8} />
      </Stage>
    </AbsoluteFill>
  );
};
