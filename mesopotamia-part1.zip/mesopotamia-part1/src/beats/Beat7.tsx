import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Stickman} from '../Stickman';
import {KingCard, SceneTitle, Stage, Tablet, usePop} from '../ui';
import {findWord, localFrame} from '../timing';
import {C, SERIF} from '../theme';
import L from '../layout.json';

type P = {start: number; dur: number};

const iMeso = findWord('mesopotamia', findWord('inilah'));

export const Beat7: React.FC<P> = ({start, dur}) => {
  const f = useCurrentFrame();
  const B = L.beats.b7;
  const zoom = interpolate(f, [0, dur], [1.12, 1], {extrapolateRight: 'clamp'});
  const drift = interpolate(f, [0, dur], [-16, 16], {extrapolateRight: 'clamp'});
  const sink = interpolate(f, [0, dur], [0, 60], {extrapolateRight: 'clamp'});
  const wm = localFrame(iMeso, start);
  const sw = usePop(wm, 9);
  return (
    <AbsoluteFill>
      <SceneTitle text="Antara Dua Sungai" />
      <Stage>
        <svg width={1080} height={1140} style={{position: 'absolute', left: 0, top: 0, transformOrigin: '540px 700px', transform: `scale(${zoom})`}}>
          <rect x={0} y={0} width={1080} height={1140} fill="#E8923F" />
          <rect x={0} y={420} width={1080} height={260} fill="#F2B25B" />
          <circle cx={700} cy={500 + sink} r={120} fill="#FFD36B" />
          <g transform={`translate(${drift * 0.4} 0)`}>
            <polygon points="-40,640 140,540 260,590 380,520 520,600 640,560 820,610 1000,540 1120,620 1120,700 -40,700" fill="#B2562F" />
          </g>
          <g transform={`translate(${drift * 0.7} 0)`}>
            <polygon points="620,690 640,660 700,660 720,630 780,630 800,600 880,600 900,630 960,630 980,660 1040,660 1060,690" fill="#6E3320" />
          </g>
          <polygon points="-60,700 1140,700 1140,1140 -60,1140" fill="#8A4A2B" />
          <polygon points="430,700 650,700 960,1140 120,1140" fill="#E8923F" />
          <g stroke="#FFD36B" strokeWidth={5} strokeLinecap="round">
            <line x1={500} y1={760} x2={560} y2={760} />
            <line x1={470} y1={850} x2={570} y2={850} />
            <line x1={520} y1={960} x2={650} y2={960} />
          </g>
          <g transform={`translate(${drift} 0)`}>
            <polygon points="-60,1010 140,960 330,1000 480,1060 560,1140 -60,1140" fill="#3A1D14" />
            <polygon points="1140,1030 900,990 760,1040 700,1140 1140,1140" fill="#3A1D14" />
          </g>
        </svg>
        <KingCard rect={B.king} img="img/king_nebukadnezar.png" name="Nebukadnezar II" role="Raja Babilonia Baru" delay={10} />
        {f >= wm ? (
          <div style={{position: 'absolute', left: B.wordmark[0], top: B.wordmark[1], width: B.wordmark[2], height: B.wordmark[3], transform: `scale(${1.5 - 0.5 * sw})`}}>
            <Tablet w={B.wordmark[2]} h={B.wordmark[3]} fill={C.ink} stroke={C.gold} sw={6} cut={20}>
              <div style={{fontFamily: SERIF, fontWeight: 900, fontSize: 76, color: C.gold, letterSpacing: 4}}>MESOPOTAMIA</div>
            </Tablet>
          </div>
        ) : null}
        <Stickman rect={B.stickman} armL={8} armR={8} back />
      </Stage>
    </AbsoluteFill>
  );
};
