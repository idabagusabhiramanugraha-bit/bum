import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {SceneTitle, Stage, Tablet, usePop} from '../ui';
import {Stickman} from '../Stickman';
import {findWord, localFrame} from '../timing';
import {C, SERIF} from '../theme';
import L from '../layout.json';

type P = {start: number; dur: number};

// Peta bergaya sederhana (lon 34-56 E, lat 28-42 N) pada kotak 1000x640.
const mx = (lon: number): number => (lon - 34) * (1000 / 22);
const my = (lat: number): number => (42 - lat) * (640 / 14);
type Pt = number[];
const pts = (a: Pt[]): string => a.map((p) => `${mx(p[0]).toFixed(1)},${my(p[1]).toFixed(1)}`).join(' ');
const dpath = (a: Pt[], close: boolean): string =>
  'M' + a.map((p) => `${mx(p[0]).toFixed(1)} ${my(p[1]).toFixed(1)}`).join(' L') + (close ? ' Z' : '');

const TURKEY: Pt[] = [[34, 42], [46, 42], [44.8, 39.7], [44.2, 37.3], [42, 37.2], [40, 37.1], [38, 36.8], [36.5, 36.6], [36, 36.2], [34, 36.2]];
const SYRIA: Pt[] = [[35.9, 36.3], [36.5, 36.6], [38, 36.8], [40, 37.1], [42, 37.2], [42.3, 37.1], [41.3, 35.7], [40.9, 34.4], [38.8, 33.4], [38.9, 32.4], [37.2, 32.9], [35.9, 33.1], [35.8, 34.6]];
const IRAQ: Pt[] = [[42.3, 37.1], [44.2, 37.3], [44.8, 37.1], [45.4, 35.9], [46.1, 35.1], [45.8, 34.4], [46.2, 33.6], [47.6, 32.9], [47.8, 31.9], [48.3, 30.1], [47.5, 29.2], [46.6, 29.1], [44.7, 29.2], [41, 31], [39.1, 32.1], [38.8, 33.4], [40.9, 34.4], [41.3, 35.7]];
const IRAN: Pt[] = [[44.8, 39.7], [48, 39.4], [50, 37.4], [54, 37.3], [56, 38], [56, 28], [52, 28], [50, 30], [48.3, 30.1], [47.8, 31.9], [47.6, 32.9], [46.2, 33.6], [45.8, 34.4], [46.1, 35.1], [45.4, 35.9], [44.8, 37.1], [44.2, 37.3]];
const MED: Pt[] = [[34, 36.2], [35.9, 36.3], [35.8, 34.6], [35.9, 33.1], [34.3, 31.5], [34, 28]];
const GULF: Pt[] = [[47.5, 29.2], [48.3, 30.1], [50, 30], [52, 28], [47, 28]];
const EUPHRATES: Pt[] = [[38.5, 36.9], [38.2, 35.9], [40.2, 35.1], [41.3, 34.4], [42.5, 34.1], [43.7, 33.2], [44.4, 32.4], [46, 31.1], [47.4, 30.4], [48.2, 30]];
const TIGRIS: Pt[] = [[40.2, 37.9], [41.5, 37.2], [42.4, 37.1], [43.1, 36.4], [43.6, 35.6], [44, 34.3], [44.4, 33.3], [45.6, 32.6], [46.6, 31.9], [47.4, 30.9], [48.1, 30]];
const BLOB: Pt[] = [[43.1, 36.4], [43.6, 35.6], [44, 34.3], [44.4, 33.3], [45.6, 32.6], [46.6, 31.9], [47.4, 30.9], [48.1, 30], [47.4, 30.4], [46, 31.1], [44.4, 32.4], [43.7, 33.2], [42.5, 34.1], [41.9, 34.3], [41.5, 35.2]];

const MAP = L.bg.map; // [40,50,1000,640]

/** Negara: garis digambar bertahap saat namanya disebut, lalu diisi warna. */
const Country: React.FC<{poly: Pt[]; fill: string; t0: number}> = ({poly, fill, t0}) => {
  const f = useCurrentFrame();
  const p = interpolate(f - t0, [0, 14], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <path
      d={dpath(poly, true)}
      pathLength={1}
      strokeDasharray={1}
      strokeDashoffset={1 - p}
      fill={f >= t0 + 10 ? fill : 'none'}
      stroke={C.ink}
      strokeWidth={4}
      strokeLinejoin="round"
    />
  );
};

const River: React.FC<{line: Pt[]; t0: number}> = ({line, t0}) => {
  const f = useCurrentFrame();
  const p = interpolate(f - t0, [0, 26], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <path d={dpath(line, false)} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} fill="none" stroke="#2F6FB0" strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" />
  );
};

const MapLabel: React.FC<{rect: number[]; text: string; delay: number}> = ({rect, text, delay}) => {
  const f = useCurrentFrame();
  const s = usePop(delay, 9);
  if (f < delay) return null;
  return (
    <div style={{position: 'absolute', left: rect[0] - MAP[0], top: rect[1] - MAP[1], width: rect[2], height: rect[3], transform: `scale(${1.6 - 0.6 * s})`}}>
      <Tablet w={rect[2]} h={rect[3]} fill={C.ink} stroke={C.gold} sw={4} cut={10}>
        <div style={{fontFamily: SERIF, fontWeight: 900, fontSize: 34, color: C.cream, letterSpacing: 2}}>{text}</div>
      </Tablet>
    </div>
  );
};

export const Beat1: React.FC<P> = ({start, dur}) => {
  const f = useCurrentFrame();
  const B = L.beats.b1;
  const wIrak = localFrame(findWord('irak'), start);
  const wSuriah = localFrame(findWord('suriah'), start);
  const wTurki = localFrame(findWord('turki'), start);
  const wIran = localFrame(findWord('iran'), start);
  const blobT = wSuriah + 26;
  const zoom = interpolate(f, [wTurki, dur - 2], [1, 1.45], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });
  const point = usePop(10, 12);
  const armR = f < 10 ? 8 : 8 + (112 + Math.sin(f / 9) * 6 - 8) * point;
  return (
    <AbsoluteFill>
      <SceneTitle text="Di Mana Mesopotamia?" />
      <Stage bg="#3A2415">
        <svg width={1080} height={1140} style={{position: 'absolute', left: 0, top: 0}}>
          {[95, 190, 285, 380, 475, 570, 665, 760, 855, 950, 1045].map((y) => (
            <line key={y} x1={0} y1={y} x2={1080} y2={y} stroke="#2A190F" strokeWidth={5} />
          ))}
          <line x1={310} y1={760} x2={310} y2={855} stroke="#2A190F" strokeWidth={5} />
          <line x1={760} y1={855} x2={760} y2={950} stroke="#2A190F" strokeWidth={5} />
        </svg>
        <div style={{position: 'absolute', left: MAP[0], top: MAP[1], width: MAP[2], height: MAP[3], overflow: 'hidden', background: C.parchment}}>
          <div style={{position: 'absolute', left: 0, top: 0, width: MAP[2], height: MAP[3], transformOrigin: '477px 389px', transform: `scale(${zoom})`}}>
            <svg width={MAP[2]} height={MAP[3]} style={{position: 'absolute', left: 0, top: 0}}>
              <polygon points={pts(MED)} fill="#9DB9C9" />
              <polygon points={pts(GULF)} fill="#9DB9C9" />
              <Country poly={TURKEY} fill="#CFB27A" t0={wTurki} />
              <Country poly={SYRIA} fill="#D8BE86" t0={wSuriah} />
              <Country poly={IRAN} fill="#C9AE74" t0={wIran} />
              <Country poly={IRAQ} fill="#D98B52" t0={wIrak} />
              {f >= blobT ? <polygon points={pts(BLOB)} fill={C.terracotta} fillOpacity={0.6} /> : null}
              <River line={EUPHRATES} t0={wSuriah} />
              <River line={TIGRIS} t0={wSuriah} />
            </svg>
            <MapLabel rect={B.labelTurki} text="TURKI" delay={wTurki} />
            <MapLabel rect={B.labelSuriah} text="SURIAH" delay={wSuriah} />
            <MapLabel rect={B.labelIrak} text="IRAK" delay={wIrak} />
            <MapLabel rect={B.labelIran} text="IRAN" delay={wIran} />
          </div>
        </div>
        <div style={{position: 'absolute', left: MAP[0], top: MAP[1], width: MAP[2], height: MAP[3], boxSizing: 'border-box', border: `8px solid ${C.ink}`}} />
        {f >= blobT ? (
          <div style={{position: 'absolute', left: B.chipMesopotamia[0], top: B.chipMesopotamia[1], width: B.chipMesopotamia[2], height: B.chipMesopotamia[3]}}>
            <Tablet w={B.chipMesopotamia[2]} h={B.chipMesopotamia[3]} fill={C.terracotta} stroke={C.cream} sw={5} cut={16}>
              <div style={{fontFamily: SERIF, fontWeight: 900, fontSize: 50, color: C.cream, letterSpacing: 3}}>MESOPOTAMIA</div>
            </Tablet>
          </div>
        ) : null}
        <Stickman rect={B.stickman} scale={0.75} armL={8} armR={armR} />
      </Stage>
    </AbsoluteFill>
  );
};
