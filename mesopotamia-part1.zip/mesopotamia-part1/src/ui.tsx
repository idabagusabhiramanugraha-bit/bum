import React from 'react';
import {Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {C, SANS, SERIF} from './theme';
import L from './layout.json';

export const box = (a: number[]): React.CSSProperties => ({
  position: 'absolute',
  left: a[0],
  top: a[1],
  width: a[2],
  height: a[3],
});

/** Spring 0..1 yang mulai pada frame lokal `delay`. */
export const usePop = (delay: number, damping = 11): number => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: f - delay, fps, config: {damping, stiffness: 140, mass: 0.7}});
};

/** Papan tanah liat dengan sudut terpotong. */
export const Tablet: React.FC<{
  w: number;
  h: number;
  fill: string;
  stroke: string;
  sw?: number;
  cut?: number;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}> = ({w, h, fill, stroke, sw = 5, cut = 14, children, style}) => {
  const pts = [[0, cut], [cut, 0], [w - cut, 0], [w, cut], [w, h - cut], [w - cut, h], [cut, h], [0, h - cut]]
    .map((p) => p.join(','))
    .join(' ');
  return (
    <div style={{position: 'relative', width: w, height: h, ...style}}>
      <svg width={w} height={h} style={{position: 'absolute', left: 0, top: 0}}>
        <polygon points={pts} fill={fill} stroke={stroke} strokeWidth={sw} strokeLinejoin="round" />
      </svg>
      <div style={{position: 'absolute', left: 0, top: 0, width: w, height: h, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
        {children}
      </div>
    </div>
  );
};

export const Stage: React.FC<{children: React.ReactNode; bg?: string}> = ({children, bg}) => {
  const g = L.global.stage;
  return (
    <div style={{position: 'absolute', left: g[0], top: g[1], width: g[2], height: g[3], overflow: 'hidden', background: bg}}>
      {children}
    </div>
  );
};

/** Judul adegan (koordinat kanvas, di atas stage). */
export const SceneTitle: React.FC<{text: string}> = ({text}) => {
  const s = usePop(2, 14);
  const g = L.global.title;
  return (
    <div style={{...box(g), transform: `translateY(${(1 - s) * -60}px)`}}>
      <Tablet w={g[2]} h={g[3]} fill={C.parchment} stroke={C.ink} sw={7} cut={18}>
        <div style={{fontFamily: SERIF, fontWeight: 900, fontSize: 54, color: C.ink, whiteSpace: 'nowrap'}}>{text}</div>
      </Tablet>
    </div>
  );
};

export const Placard: React.FC<{rect: number[]; text: string; delay: number}> = ({rect, text, delay}) => {
  const f = useCurrentFrame();
  const s = usePop(delay, 9);
  if (f < delay) return null;
  return (
    <div style={{...box(rect), transform: `scale(${1.7 - 0.7 * s}) rotate(${-2 * s}deg)`}}>
      <Tablet w={rect[2]} h={rect[3]} fill={C.terracotta} stroke={C.ink} sw={7} cut={20}>
        <div style={{fontFamily: SERIF, fontWeight: 900, fontSize: 80, color: C.cream, letterSpacing: 4}}>{text}</div>
      </Tablet>
    </div>
  );
};

export const YearChip: React.FC<{rect: number[]; text: string; delay: number}> = ({rect, text, delay}) => {
  const s = usePop(delay);
  return (
    <div style={{...box(rect), transform: `translateX(${(1 - s) * -400}px)`}}>
      <Tablet w={rect[2]} h={rect[3]} fill={C.lapis} stroke={C.gold} sw={5} cut={10}>
        <div style={{fontFamily: SERIF, fontWeight: 900, fontSize: 38, color: C.gold}}>{text}</div>
      </Tablet>
    </div>
  );
};

export const KingCard: React.FC<{rect: number[]; img: string; name: string; role: string; delay: number}> = ({rect, img, name, role, delay}) => {
  const s = usePop(delay, 13);
  return (
    <div style={{...box(rect), left: rect[0] + (1 - s) * 420, background: C.gold}}>
      <div style={{position: 'absolute', left: 6, top: 6, width: rect[2] - 12, height: 318, overflow: 'hidden', background: C.ink}}>
        <Img src={staticFile(img)} style={{width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center top'}} />
      </div>
      <div style={{position: 'absolute', left: 6, top: 330, width: rect[2] - 12, height: 54, background: C.ink, textAlign: 'center'}}>
        <div style={{fontFamily: SERIF, fontWeight: 900, fontSize: 30, lineHeight: '32px', color: C.cream}}>{name}</div>
        <div style={{fontFamily: SANS, fontWeight: 700, fontSize: 18, lineHeight: '22px', color: C.gold}}>{role}</div>
      </div>
    </div>
  );
};

/** Penanda kota: tiang tumbuh dari tanah, lalu papan nama muncul. Rect tinggi 140: tiang 0..60, papan 60..140. */
export const Pin: React.FC<{rect: number[]; label: string; delay: number}> = ({rect, label, delay}) => {
  const f = useCurrentFrame();
  const grow = interpolate(f - delay, [0, 8], [0, 60], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const s = usePop(delay + 6, 10);
  if (f < delay) return null;
  const cx = rect[2] / 2;
  return (
    <div style={box(rect)}>
      <svg width={rect[2]} height={60} style={{position: 'absolute', left: 0, top: 0}}>
        <line x1={cx} y1={60} x2={cx} y2={60 - grow} stroke={C.ink} strokeWidth={6} strokeLinecap="round" />
        {grow > 40 ? <polygon points={`${cx},${60 - grow} ${cx + 44},${60 - grow + 14} ${cx},${60 - grow + 28}`} fill={C.terracotta} stroke={C.ink} strokeWidth={4} /> : null}
      </svg>
      <div style={{position: 'absolute', left: 0, top: 60, transform: `scale(${s})`, transformOrigin: '50% 0%'}}>
        <Tablet w={rect[2]} h={80} fill={C.parchment} stroke={C.ink} sw={5} cut={10}>
          <div style={{fontFamily: SERIF, fontWeight: 900, fontSize: 40, color: C.ink}}>{label}</div>
        </Tablet>
      </div>
    </div>
  );
};
