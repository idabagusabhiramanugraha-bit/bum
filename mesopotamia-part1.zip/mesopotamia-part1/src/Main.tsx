import React from 'react';
import {AbsoluteFill, Sequence, staticFile} from 'remotion';
import {Audio} from '@remotion/media';
import {Beat1} from './beats/Beat1';
import {Beat2, Beat3, Beat4, Beat5} from './beats/Beats2to5';
import {Beat6} from './beats/Beat6';
import {Beat7} from './beats/Beat7';
import {Subtitle} from './Subtitle';
import {Wipe} from './Wipe';
import {BEAT_DURS, BEAT_STARTS} from './timing';
import {C} from './theme';

const BEATS: React.FC<{start: number; dur: number}>[] = [Beat1, Beat2, Beat3, Beat4, Beat5, Beat6, Beat7];

export const Main: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: C.night}}>
    <Audio src={staticFile('narasi.mp3')} />
    {BEATS.map((Comp, i) => (
      <Sequence key={i} from={BEAT_STARTS[i]} durationInFrames={BEAT_DURS[i]} name={`Beat ${i + 1}`}>
        <Comp start={BEAT_STARTS[i]} dur={BEAT_DURS[i]} />
      </Sequence>
    ))}
    {BEAT_STARTS.slice(1).map((s, i) => (
      <Wipe key={i} at={s} />
    ))}
    <Subtitle />
  </AbsoluteFill>
);
