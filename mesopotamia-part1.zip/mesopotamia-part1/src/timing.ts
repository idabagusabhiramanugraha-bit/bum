import {WORDS} from './captions';
import {AUDIO_OFFSET, FPS} from './config';

export const sec2f = (s: number): number => Math.round(s * FPS);
const norm = (s: string): string => s.toLowerCase().replace(/[^a-z-]/g, '');

/** Frame (global) saat kata ke-i mulai diucapkan, sudah termasuk AUDIO_OFFSET. */
export const wordFrame = (i: number): number => sec2f(WORDS[i].start + AUDIO_OFFSET);
export const wordEndFrame = (i: number): number => sec2f(WORDS[i].end + AUDIO_OFFSET);

/** Cari indeks kata pertama dari sebuah frasa (huruf kecil, tanda baca diabaikan). */
export const findPhrase = (phrase: string[], from = 0): number => {
  const p = phrase.map(norm);
  for (let i = from; i <= WORDS.length - p.length; i++) {
    if (p.every((x, k) => norm(WORDS[i + k].w) === x)) return i;
  }
  throw new Error('Frasa tidak ditemukan di captions.ts: ' + phrase.join(' '));
};
export const findWord = (w: string, from = 0): number => findPhrase([w], from);

export const LAST_END = WORDS[WORDS.length - 1].end;
/** Durasi total = kata terakhir + 1 detik. */
export const TOTAL_FRAMES = sec2f(LAST_END + AUDIO_OFFSET + 1);

// ---- Beat: tiap beat mulai 4 frame sebelum kata pembuka (tertutup wipe) ----
const LEAD = 4;
const anchors: number[] = [
  findPhrase(['di', 'bagian', 'selatan']),
  findPhrase(['di', 'bagian', 'tengah']),
  findPhrase(['tak', 'jauh', 'dari']),
  findPhrase(['sementara', 'di', 'bagian']),
  findPhrase(['selain', 'kerajaan-kerajaan']),
  findPhrase(['inilah', 'mesopotamia']),
];
export const BEAT_STARTS: number[] = [0, ...anchors.map((i) => Math.max(1, wordFrame(i) - LEAD))];
export const BEAT_DURS: number[] = BEAT_STARTS.map((s, k) =>
  (k + 1 < BEAT_STARTS.length ? BEAT_STARTS[k + 1] : TOTAL_FRAMES) - s,
);

/** Frame lokal (di dalam Sequence beat) untuk kata ke-i. */
export const localFrame = (i: number, beatStart: number): number => Math.max(0, wordFrame(i) - beatStart);

// ---- Subtitle: potongan kata dihitung dari data kata ----
export type Chunk = {words: number[]; start: number; end: number};
export const CHUNKS: Chunk[] = (() => {
  const groups: number[][] = [];
  let cur: number[] = [];
  let chars = 0;
  WORDS.forEach((wd, i) => {
    const len = wd.w.length;
    if (cur.length > 0 && (chars + 1 + len > 32 || cur.length >= 4)) {
      groups.push(cur);
      cur = [];
      chars = 0;
    }
    cur.push(i);
    chars += (chars > 0 ? 1 : 0) + len;
    if (/[.,]$/.test(wd.w) && cur.length >= 2) {
      groups.push(cur);
      cur = [];
      chars = 0;
    }
  });
  if (cur.length) groups.push(cur);
  return groups.map((g, k) => ({
    words: g,
    start: wordFrame(g[0]),
    end: k + 1 < groups.length ? wordFrame(groups[k + 1][0]) : wordEndFrame(g[g.length - 1]) + sec2f(0.6),
  }));
})();
