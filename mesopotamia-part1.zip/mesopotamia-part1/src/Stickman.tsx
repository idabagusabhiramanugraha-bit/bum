import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from './theme';

/**
 * Stickman narator berjubah merah (mengikuti lembar karakter), digambar sebagai SVG.
 * armL/armR = sudut angkat lengan dalam derajat: 0 menggantung, 90 mendatar ke samping, 170 lurus ke atas.
 * armL = lengan di sisi kiri layar, armR = sisi kanan layar.
 */
export const Stickman: React.FC<{
  rect: number[];
  scale?: number;
  armL?: number;
  armR?: number;
  back?: boolean;
}> = ({rect, scale = 1, armL = 8, armR = 8, back = false}) => {
  const f = useCurrentFrame();
  const bob = Math.sin(f / 14) * 4;
  const arm = (cx: number, raise: number, sign: number) => (
    <g transform={`translate(${cx} 152) rotate(${sign * raise})`}>
      <line x1={0} y1={0} x2={0} y2={118} stroke="#111" strokeWidth={10} strokeLinecap="round" />
      <circle cx={0} cy={122} r={12} fill="#111" />
    </g>
  );
  return (
    <div style={{position: 'absolute', left: rect[0], top: rect[1], width: rect[2], height: rect[3]}}>
      <svg width={300 * scale} height={520 * scale} viewBox="0 0 300 520" style={{overflow: 'visible', transform: `translateY(${bob * scale}px)`}}>
        <ellipse cx={150} cy={506} rx={96} ry={12} fill="rgba(0,0,0,0.28)" />
        <line x1={128} y1={380} x2={124} y2={492} stroke="#111" strokeWidth={10} strokeLinecap="round" />
        <line x1={172} y1={380} x2={176} y2={492} stroke="#111" strokeWidth={10} strokeLinecap="round" />
        <ellipse cx={116} cy={498} rx={24} ry={11} fill="#5A3A1F" stroke="#111" strokeWidth={3} />
        <ellipse cx={184} cy={498} rx={24} ry={11} fill="#5A3A1F" stroke="#111" strokeWidth={3} />
        <path d="M104 136 L196 136 L262 478 Q150 500 38 478 Z" fill={C.cape} stroke="#111" strokeWidth={5} strokeLinejoin="round" />
        {back ? null : <path d="M138 142 L162 142 L168 470 L132 470 Z" fill="#D9B98A" stroke="#111" strokeWidth={3} />}
        <path d="M40 472 Q150 494 260 472" fill="none" stroke={C.gold} strokeWidth={8} strokeLinecap="round" />
        <path d="M106 138 Q150 172 194 138" fill="#6E1A12" stroke="#111" strokeWidth={5} />
        {back ? null : <circle cx={150} cy={146} r={9} fill={C.gold} stroke="#111" strokeWidth={3} />}
        {arm(110, armL, 1)}
        {arm(190, armR, -1)}
        <circle cx={150} cy={74} r={60} fill="#FFFFFF" stroke="#111" strokeWidth={8} />
        {back ? (
          <path d="M98 72 Q150 14 202 72" fill="none" stroke="#111" strokeWidth={6} strokeLinecap="round" />
        ) : (
          <>
            <line x1={131} y1={58} x2={131} y2={90} stroke="#111" strokeWidth={7} strokeLinecap="round" />
            <line x1={169} y1={58} x2={169} y2={90} stroke="#111" strokeWidth={7} strokeLinecap="round" />
          </>
        )}
      </svg>
    </div>
  );
};
