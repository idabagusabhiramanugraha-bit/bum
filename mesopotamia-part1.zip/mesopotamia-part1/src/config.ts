export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
/**
 * Geser sinkron (detik). Semua visual dan caption memakai waktu SRT + AUDIO_OFFSET.
 * Naikkan nilainya jika gambar/teks muncul LEBIH CEPAT dari suara; turunkan (boleh negatif)
 * jika LEBIH LAMBAT. Contoh: 0.15 atau -0.2.
 */
export const AUDIO_OFFSET = 0;
