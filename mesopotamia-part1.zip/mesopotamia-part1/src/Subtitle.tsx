import React from 'react';
import {useCurrentFrame} from 'remotion';
import {WORDS} from './captions';
import {CHUNKS, wordFrame} from './timing';
import {C, SANS} from './theme';
import {Tablet, box} from './ui';
import L from './layout.json';

const lineLen = (ids: number[]): number => ids.reduce((a, i) => a + WORDS[i].w.length, 0) + Math.max(0, ids.length - 1);

/** Subtitle besar-tebal dengan kotak kuning di kata yang sedang diucapkan. Posisi tetap (koordinat kanvas). */
export const Subtitle: React.FC = () => {
  const f = useCurrentFrame();
  const chunk = CHUNKS.find((c) => f >= c.start && f < c.end);
  if (!chunk) return null;
  let active = chunk.words[0];
  chunk.words.forEach((i) => {
    if (f >= wordFrame(i)) active = i;
  });
  const ws = chunk.words;
  let split = ws.length;
  let bestMax = Number.MAX_SAFE_INTEGER;
  for (let k = 1; k < ws.length; k++) {
    const m = Math.max(lineLen(ws.slice(0, k)), lineLen(ws.slice(k)));
    if (m < bestMax) {
      bestMax = m;
      split = k;
    }
  }
  const lines = split >= ws.length ? [ws] : [ws.slice(0, split), ws.slice(split)];
  const longest = Math.max(...lines.map(lineLen));
  const fontSize = longest > 22 ? 54 : 62;
  const g = L.global.subtitle;
  return (
    <div style={box(g)}>
      <Tablet w={g[2]} h={g[3]} fill="#2B1A10" stroke={C.gold} sw={6} cut={22}>
        <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6}}>
          {lines.map((ln, li) => (
            <div key={li} style={{display: 'flex', justifyContent: 'center', whiteSpace: 'nowrap'}}>
              {ln.map((i) => (
                <span
                  key={i}
                  style={{
                    display: 'inline-block',
                    padding: '2px 12px',
                    margin: '0 3px',
                    fontFamily: SANS,
                    fontWeight: 900,
                    fontSize,
                    lineHeight: 1.25,
                    background: i === active ? C.yellow : 'transparent',
                    color: i === active ? C.ink : C.cream,
                  }}
                >
                  {WORDS[i].w}
                </span>
              ))}
            </div>
          ))}
        </div>
      </Tablet>
    </div>
  );
};
