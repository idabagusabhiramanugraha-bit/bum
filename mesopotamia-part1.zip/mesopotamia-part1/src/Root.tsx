import React from 'react';
import {Composition} from 'remotion';
import {Main} from './Main';
import {FPS, HEIGHT, WIDTH} from './config';
import {TOTAL_FRAMES} from './timing';

export const Root: React.FC = () => (
  <Composition
    id="MesopotamiaPart1"
    component={Main}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
