// Memeriksa bahwa tidak ada dua kotak yang tumpang tindih (lihat LAYOUT.md).
import fs from 'node:fs';
const L = JSON.parse(fs.readFileSync('src/layout.json', 'utf8'));
const ov = (a, b) => a[0] < b[0] + b[2] && b[0] < a[0] + a[2] && a[1] < b[1] + b[3] && b[1] < a[1] + a[3];
let ok = true;
const g = Object.entries(L.global);
for (let i = 0; i < g.length; i++) for (let j = i + 1; j < g.length; j++)
  if (ov(g[i][1], g[j][1])) { console.log('TUMPANG TINDIH global:', g[i][0], g[j][0]); ok = false; }
for (const [b, els] of Object.entries(L.beats)) {
  const ks = Object.keys(els);
  for (const n of ks) { const r = els[n]; if (r[0] < 0 || r[1] < 0 || r[0] + r[2] > 1080 || r[1] + r[3] > 1140) { console.log('KELUAR STAGE:', b, n); ok = false; } }
  for (let i = 0; i < ks.length; i++) for (let j = i + 1; j < ks.length; j++)
    if (ov(els[ks[i]], els[ks[j]])) { console.log('TUMPANG TINDIH:', b, ks[i], ks[j]); ok = false; }
}
console.log(ok ? 'OK: tidak ada tumpang tindih' : 'ADA MASALAH');
process.exit(ok ? 0 : 1);
