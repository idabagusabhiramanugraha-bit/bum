// Membuat src/captions.ts dari data/narasi.srt.
// Jika SRT hanya per kalimat/frasa, waktu tiap kata dibagi proporsional jumlah hurufnya di dalam cue itu.
import fs from 'node:fs';

const srt = fs.readFileSync('data/narasi.srt', 'utf8').replace(/\r/g, '');
const toSec = (t) => {
  const m = t.match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4]) / 1000;
};
const words = [];
srt.trim().split(/\n\s*\n/).forEach((block, cue) => {
  const lines = block.split('\n');
  const ti = lines.findIndex((l) => l.includes('-->'));
  const [a, b] = lines[ti].split('-->').map((s) => toSec(s.trim()));
  const ws = lines.slice(ti + 1).join(' ').trim().split(/\s+/).filter(Boolean);
  const lens = ws.map((w) => w.replace(/[^\p{L}\p{N}]/gu, '').length || 1);
  const total = lens.reduce((x, y) => x + y, 0);
  let cur = a;
  ws.forEach((w, i) => {
    const d = ((b - a) * lens[i]) / total;
    words.push({w, start: Number(cur.toFixed(3)), end: Number((cur + d).toFixed(3)), cue});
    cur += d;
  });
});
const out =
  '// FILE HASIL GENERATE dari data/narasi.srt (npm run captions). Jangan edit manual.\n' +
  'export type Word = {w: string; start: number; end: number; cue: number};\n' +
  'export const WORDS: Word[] = ' + JSON.stringify(words, null, 1) + ';\n';
fs.writeFileSync('src/captions.ts', out);
console.log('Selesai:', words.length, 'kata; kata terakhir berakhir di', words[words.length - 1].end, 'detik');
