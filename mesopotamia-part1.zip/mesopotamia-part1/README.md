# Mesopotamia Part 1 — Kelahiran Peradaban Pertama (Remotion)

Video vertikal 1080×1920, 30 fps, ±51,8 detik, 7 beat.

## Yang WAJIB kamu ganti
- `public/narasi.mp3` sekarang berisi **audio hening 52 detik (penanda)**. Timpa dengan rekaman narasimu (nama file harus sama).

## Perintah
- `npm install`
- `npm run dev` → pratinjau di browser
- `npm run render` → hasil di `out/mesopotamia-part1.mp4`
- `npm run captions` → buat ulang `src/captions.ts` bila `data/narasi.srt` kamu ubah
- `npm run check:layout` → cek tidak ada kotak yang tumpang tindih (lihat `LAYOUT.md`)

## Sinkron
Buka `src/config.ts`, ubah `AUDIO_OFFSET` (detik). Naikkan jika gambar/teks lebih cepat dari suara.

## Struktur
- `data/narasi.srt` → `src/captions.ts` (timestamp per kata, dibagi proporsional jumlah huruf)
- `src/timing.ts` → durasi total (kata terakhir + 1 dtk), batas beat, potongan subtitle; semuanya dihitung dari data kata
- `src/layout.json` → koordinat eksplisit semua elemen (tabel di `LAYOUT.md`)
- `src/beats/` → satu komponen per beat; `src/Main.tsx` menyusun Sequence + Wipe + Subtitle + Audio
- `public/img/` → potongan latar dan potret raja dari gambar yang kamu kirim
